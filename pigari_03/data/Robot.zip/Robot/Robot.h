#ifndef ROBOT_H  //memeriksa jika ROBOT_H tidak ada
#define ROBOT_H  //mendefinisikan ROBOT_H

#include "Arduino.h" //menambahkan library Arduino.h
 
class Robot //membuat class dengan nama Robot
{
 public: //membuat fungsi atau variabel yang bersifat public
   Robot (byte pinPwmA1, byte pinPwmA2, byte pinPwmB1, byte pinPwmB2); //deklarasi konstruktor dengan 4 variabel yang memiliki tipe data byte
   void maju (unsigned long lama); //deklarasi fungsi maju yang menyimpan parameter lama
   void mundur (unsigned long lama); //deklarasi fungsi mundur yang menyimpan parameter lama
   void stop (unsigned long lama); //deklarasi fungsi stop yang menyimpan parameter lama
   void belokKiri (unsigned long lama);  //deklarasi fungsi belokKiri yang menyimpan parameter lama
   void belokKanan (unsigned long lama); //deklarasi fungsi belokKanan yang menyimpan parameter lama
   void putarKiri (unsigned long lama); //deklarasi fungsi putarKiri yang menyimpan parameter lama
   void putarKanan (unsigned long lama); //deklarasi fungsi putarKanan yang menyimpan parameter lama
   void aturKecepatan (byte kecepatan); //deklarasi fungsi aturKecepatan yang menyimpan parameter kecepatan
   byte perolehKecepatan(); //deklarasi fungsi perolehKecepatan
   
 private:
   byte pinIN1, pinIN2, pinIN3, pinIN4; //deklarasi variabel pinIN1, pinIN2, pinIN3, pinIN4
   byte kecepatan; //deklarasi variabel kecepatan
};

#endif //mengakhiri blok kondisi if




