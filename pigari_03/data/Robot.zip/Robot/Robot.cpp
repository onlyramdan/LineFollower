#include <Robot.h> //menambahkan library Robot.h

//Konstruktor
Robot::Robot(byte pinIN1, byte pinIN2, byte pinIN3, byte pinIN4) //mendefinisikan konstruktor dan mendeklarasikan variabel
{
 pinMode(pinIN1, OUTPUT); //membuat pinIN1 sebagai output
 pinMode(pinIN2, OUTPUT); //membuat pinIN2 sebagai output
 pinMode(pinIN3, OUTPUT); //membuat pinIN3 sebagai output
 pinMode(pinIN4, OUTPUT); //membuat pinIN4 sebagai output
 
 Robot::pinIN1 = pinIN1; //konstruktor untuk pinIN1
 Robot::pinIN2 = pinIN2; //konstruktor untuk pinIN2
 Robot::pinIN3 = pinIN3; //konstruktor untuk pinIN3
 Robot::pinIN4 = pinIN4; //konstruktor untuk pinIN4
 
 kecepatan = 50; // 50%
}

//Menggerakan robot ke depan selama lama milidetik
void Robot::maju(unsigned long lama) //mengambil fungsi maju dan parameter lama dari kelas Robot
{
 byte nilaiAnalog = kecepatan / 100.0 * 255; //membuat variabel nilaiAnalog yang merupakan hasil dari perhitungan tersebut
 
 analogWrite(pinIN1, nilaiAnalog); //menuliskan nilai analog ke pinIN1
 digitalWrite(pinIN2, LOW); //memberi nilai LOW pada pinIN2
 
 analogWrite(pinIN3, nilaiAnalog); //menuliskan nilai analog ke pinIN3
 digitalWrite(pinIN4, LOW); //memberi nilai LOW pada pinIN4
 
 delay(lama); //melakukan delay selama nilai variabel lama milidetik
 stop(0); //stop
}

//Menggerakan robot ke belakang selama lama milidetik
void Robot::mundur(unsigned long lama) //mengambil fungsi mundur dan parameter lama dari kelas Robot
{
 byte nilaiAnalog = kecepatan / 100.0 * 255; //membuat variabel nilaiAnalog yang merupakan hasil dari perhitungan tersebut
 
 digitalWrite(pinIN1, LOW); //memberi nilai LOW pada pinIN1
 analogWrite(pinIN2, nilaiAnalog); //menuliskan nilai analog ke pinIN2
 
 digitalWrite(pinIN3, LOW); //memberi nilai LOW pada pinIN3
 analogWrite(pinIN4, nilaiAnalog); //menuliskan nilai analog ke pinIN4
 
 delay(lama); //melakukan delay selama nilai variabel lama milidetik
 stop(0); //stop
}

///Menghentikan robot
void Robot::stop(unsigned long lama) //mengambil fungsi stop dan parameter lama dari kelas Robot
{
 digitalWrite(pinIN1, LOW); //memberi nilai LOW pada pinIN1
 digitalWrite(pinIN2, LOW); //memberi nilai LOW pada pinIN2
 
 digitalWrite(pinIN3, LOW); //memberi nilai LOW pada pinIN3
 digitalWrite(pinIN4, LOW); //memberi nilai LOW pada pinIN4
 
 delay(lama); //melakukan delay selama nilai variabel lama milidetik
}

//Robot dibelokkan ke kiri selama lama milidetik
void Robot::belokKiri(unsigned long lama) //mengambil fungsi belokKiri dan parameter lama dari kelas Robot
{
 byte nilaiAnalog = kecepatan / 100.0 * 255; //membuat variabel nilaiAnalog yang merupakan hasil dari perhitungan tersebut
 
 digitalWrite(pinIN1, LOW); //memberi nilai LOW pada pinIN1
 digitalWrite(pinIN2, LOW); //memberi nilai LOW pada pinIN2
 
 analogWrite(pinIN3, nilaiAnalog); //menuliskan nilai analog ke pinIN3
 digitalWrite(pinIN4, LOW); //memberi nilai LOW pada pinIN4
 
 delay(lama); //melakukan delay selama nilai variabel lama milidetik
 stop(0); //stop
}

//Robot dibelokkan ke kanan selama lama milidetik
void Robot::belokKanan(unsigned long lama) //mengambil fungsi belokKanan dan parameter lama dari kelas Robot
{
 byte nilaiAnalog = kecepatan / 100.0 * 255; //membuat variabel nilaiAnalog yang merupakan hasil dari perhitungan tersebut
 
 analogWrite(pinIN1, nilaiAnalog); //menuliskan nilai analog ke pinIN1
 digitalWrite(pinIN2, LOW); //memberi nilai LOW pada pinIN2
 
 digitalWrite(pinIN3, LOW); //memberi nilai LOW pada pinIN3
 digitalWrite(pinIN4, LOW); //memberi nilai LOW pada pinIN4
 
 delay(lama); //melakukan delay selama nilai variabel lama milidetik
 stop(0); //stop
}

//Robot diputar ke kiri selama lama milidetik
void Robot::putarKiri(unsigned long lama) //mengambil fungsi putarKiri dan parameter lama dari kelas Robot
{
 byte nilaiAnalog = kecepatan / 100.0 * 255; //membuat variabel nilaiAnalog yang merupakan hasil dari perhitungan tersebut
  
 digitalWrite(pinIN1, LOW); //memberi nilai LOW pada pinIN1
 analogWrite(pinIN2, nilaiAnalog); //menuliskan nilai analog ke pinIN2
 
 analogWrite(pinIN3, nilaiAnalog); //menuliskan nilai analog ke pinIN3
 digitalWrite(pinIN4, LOW); //memberi nilai LOW pada pinIN4
 
 delay(lama); //melakukan delay selama nilai variabel lama milidetik
 stop(0); //stop
}

//Robot diputar ke kanan selama lama milidetik
void Robot::putarKanan(unsigned long lama) //mengambil fungsi putarKanan dan parameter lama dari kelas Robot
{
 byte nilaiAnalog = kecepatan / 100.0 * 255; //membuat variabel nilaiAnalog yang merupakan hasil dari perhitungan tersebut
 
 analogWrite(pinIN1, nilaiAnalog); //menuliskan nilai analog ke pinIN1
 digitalWrite(pinIN2, LOW); //memberi nilai LOW pada pinIN2
 
 digitalWrite(pinIN3, LOW); //memberi nilai LOW pada pinIN3
 analogWrite(pinIN4, nilaiAnalog); //menuliskan nilai analog ke pinIN4
 
 delay(lama); //melakukan delay selama nilai variabel lama milidetik
 stop(0); //stop
}

//Untuk mengatur kecepatan dalam persen
void Robot::aturKecepatan(byte kecepatan) //mengambil fungsi aturKecepatan dan parameter kecepatan dari kelas Robot
{
 if (kecepatan <= 100) //jika nilai kecepatan kecil dari sama dengan 100
   Robot::kecepatan = kecepatan; //maka nilai kecepatan pada konstruktor Robot akan berubah menjadi nilai kecepatan yang diinputkan
}

//Untuk memperoleh kecepatan
byte Robot::perolehKecepatan() //mengambil fungsi perolehKecepatan dari fungsi Robot
{
 return kecepatan; //mengembalikan nilai kecepatan
}
